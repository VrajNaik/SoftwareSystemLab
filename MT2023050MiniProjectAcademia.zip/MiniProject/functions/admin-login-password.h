/*
This file consists of admin credentials
*/
#ifndef ADMIN_CREDENTIALS
#define ADMIN_CREDENTIALS

#define ADMIN_LOGIN_ID "admin"
#define ADMIN_PASSWORD "vraj" 

#endif
