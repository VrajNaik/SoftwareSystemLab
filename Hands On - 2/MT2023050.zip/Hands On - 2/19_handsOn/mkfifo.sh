#!/bin/bash
mkfifo myfifo_mkfifo

