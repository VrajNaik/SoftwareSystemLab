#!/bin/bash
mknod myfifo_mknod p

